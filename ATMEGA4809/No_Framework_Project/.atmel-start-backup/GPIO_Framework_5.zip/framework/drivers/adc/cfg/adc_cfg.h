/**
 * @file adc_cfg.h
 * @author Cesar Rodriguez
 * @brief ADC framework configuration header
 */

/************************
 * Guard                *
 ************************/
#ifndef _ADC_CFG_H_
#define _ADC_CFG_H_

/************************
 * Includes             *
 ************************/
// ################## Kamino generator v1.0.0: Generated code! ################
// ######## Do NOT modify code between this header and the footer below #######
#include "adc_basic.h"
// ################## Kamino generator v1.0.0: Generated code! ################
// ######## Do NOT modify code between this footer and the header above #######

/************************
 * Public Types         *
 ************************/
/**
 * @brief GPIO elements
 */
typedef enum
{
    // ################## Kamino generator v1.0.0: Generated code! ################
// ######## Do NOT modify code between this header and the footer below #######
    MCU_ADC1,
// ################## Kamino generator v1.0.0: Generated code! ################
// ######## Do NOT modify code between this footer and the header above #######
    ADC_ELEMENTS_MAX
} Adc_elementsType;

/************************
 * Public Macros        *
 ************************/

/************************
 * Public Defines       *
 ************************/
// ################## Kamino generator v1.0.0: Generated code! ################
// ######## Do NOT modify code between this header and the footer below #######

// ################## Kamino generator v1.0.0: Generated code! ################
// ######## Do NOT modify code between this footer and the header above #######

// ################## Kamino generator v1.0.0: Generated code! ################
// ######## Do NOT modify code between this header and the footer below #######

// ADC1
#define MCU_ADC1_ID ADC_1
#define MCU_ADC1_SAMPLES ADC_DISABLE_SAMPLE
#define MCU_ADC1_CLOCK INTERNAL_CLOCK_FOR_ADC
#define MCU_ADC1_JUSTIFICATION ADC_RIGHT_JUSTIFIED
#define MCU_ADC1_PRESCALER DIVIDE_ADC_CLOCK_BY_4
#define MCU_ADC1_RESOLUTION ADC_10_BIT_RESOLUTION
#define MCU_ADC1_REFERENCE ADC_USE_SUPPLY_VOLTAGE_AS_REFERENCE

// ################## Kamino generator v1.0.0: Generated code! ################
// ######## Do NOT modify code between this footer and the header above #######

/************************
 * Public Constants     *
 ************************/

/************************
 * Public Calibrations  *
 ************************/

/************************
 * Public Variables     *
 ************************/

/************************
 * Public Functions     *
 ************************/

#endif /* _ADC_CFG_H_ */
