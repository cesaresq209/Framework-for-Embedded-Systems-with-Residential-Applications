/******************************************************************************
*. Copyright 2020 Cesar Rodriguez, All Rights Reserved
*.=============================================================================
*. Template C Source File
*.=============================================================================
*. FILE: main.c
*.
*. DESCRIPTION:
*. This file
*.
*. SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" FOR THE PURPOSES OF THE
*. PROVIDED TRAINING CLASS AND IT IS NOT INTENDED AS PRODUCTION CODE AND WITHOUT
*. WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION,
*. ANY WARRANTY OF MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A
*. PARTICULAR PURPOSE. IN NO EVENT SHALL SALVADOR ALMANZA OR ITS LICENSORS BE LIABLE OR
*. OBLIGATED UNDER CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH
*. OF WARRANTY, OR OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES
*. OR EXPENSES INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT,
*. PUNITIVE OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF
*. PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD
*. PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR
*. COSTS.
*.
\*****************************************************************************/
/***********************
 * Includes             *
 ***********************/
#include "frameworkCommon.h"
#include "frameworkIncludes.h"
#include <main.h>
/***********************
 * Type Definitions     *
 ***********************/

/***********************
 * Macros               *
 ***********************/

/***********************
 * Defines              *
 ***********************/

/***********************
 * Constants            *
 ***********************/

/***********************
 * Calibrations         *
 ***********************/

/***********************
 * Global Variables     *
 ***********************/

/***********************
 * File Scope Variables *
 ***********************/

/***********************
 * Function Prototypes  *
 ***********************/

/***********************
 * Function Definitions *
 ***********************/

/*********************************************************************
*. Name: main
*.====================================================================
*. Description:
*. C entry point, executes the systems initialization and application
*.
\********************************************************************/
int main(void)
{
	Gpio_pinState_t ledState = LED_OFF;
	volatile uint16_t ADC_Value = 0;
    volatile float voltage =0;
    // Initialize basic hardware functionality
    HWInit();
    // Initialize GPIOs
    Gpio_InitDefaults(Gpio_Cfg);
    //Initialize ADC
    Adc_Init(Adc_Cfg);
    //Perform ADC Calibration
    Adc_CalibrateAdc(MCU_ADC1_ID);
    //Select ADC Channel
    Adc_SetChannel(MCU_ADC1_ID, ADC_CHANNEL_0);
	//Enable ADC
	Adc_EnableAdc(MCU_ADC1_ID);
	while (true) 
	{
		if(USART_0_read() == 48)
		{
		    Adc_StartConversion(MCU_ADC1_ID);
		    while(Adc_GetConversionStatus(MCU_ADC1_ID) != CONVERSION_READY)
		    {
		    }
		    ADC_Value = Adc_GetResult(MCU_ADC1_ID);
		    //if (Gpio_GetPin(USER_BUTTON_PORT, USER_BUTTON_PIN) == BUTTON_PRESSED)
		    voltage = (3.27*ADC_Value)/1023;
		    if(voltage < 2.5)
            {
	            ledState = LED_ON;
            }
            else
            {
	            ledState = LED_OFF;
            }
            Gpio_SetPin(USER_LED_PORT, USER_LED_PIN, ledState);
		}
	}
}
