#include <atmel_start.h>
#include <main.h>
#include "frameworkCommon.h"
#include "frameworkIncludes.h"

int main(void)
{
	HWInit();
	Gpio_Init(Gpio_Cfg);
	
	Gpio_pinState_t ledState = LED_OFF;
	while (1) 
	{
        if (Gpio_GetPin(USER_BUTTON_PORT, USER_BUTTON_PIN) == BUTTON_PRESSED)
        {
	        ledState = LED_ON;
        }
        else
        {
	        ledState = LED_OFF;
        }
        Gpio_SetPin(USER_LED_PORT, USER_LED_PIN, ledState);
	}
}
