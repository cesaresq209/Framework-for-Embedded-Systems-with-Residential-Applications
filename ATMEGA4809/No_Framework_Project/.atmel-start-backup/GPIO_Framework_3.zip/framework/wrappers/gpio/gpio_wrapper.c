/******************************************************************************
 *. Copyright 2020 C�sar Rodr�guez, All Rights Reserved
 *.=============================================================================
 *. Template C Source File
 *.=============================================================================
 *. FILE: main.c
 *.
 *. DESCRIPTION:
 *. This file
 *.
 *. SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" FOR THE PURPOSES OF THE
 *. PROVIDED TRAINING CLASS AND IT IS NOT INTENDED AS PRODUCTION CODE AND WITHOUT
 *. WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION,
 *. ANY WARRANTY OF MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A
 *. PARTICULAR PURPOSE. IN NO EVENT SHALL SALVADOR ALMANZA OR ITS LICENSORS BE LIABLE OR
 *. OBLIGATED UNDER CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH
 *. OF WARRANTY, OR OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES
 *. OR EXPENSES INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT,
 *. PUNITIVE OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF
 *. PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD
 *. PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR
 *. COSTS.
 *.
 \*****************************************************************************/
/***********************
 * Includes             *
 ***********************/
#include "gpio_wrapper.h"

/***********************
 * Type Definitions     *
 ***********************/

/***********************
 * Macros               *
 ***********************/

/***********************
 * Defines              *
 ***********************/

/***********************
 * Constants            *
 ***********************/

/***********************
 * Calibrations         *
 ***********************/

/***********************
 * Global Variables     *
 ***********************/

/***********************
 * File Scope Variables *
 ***********************/

/***********************
 * Function Prototypes  *
 ***********************/

/***********************
 * Function Definitions *
 ***********************/

/**
 * @brief Set pin's mode
 * @param port Pin's port
 * @param pin Pin
 * @param mode Mode
 */
void GpioWrapper_setMode(Gpio_portId_t port, Gpio_pinId_t pin, Gpio_mode_t mode)
{
	switch(port)
	{		
		case PORT_A:
		    PORTA_set_pin_dir(pin,mode);
		    break;
		case PORT_B:
		    PORTB_set_pin_dir(pin,mode);
		    break;
		case PORT_C:
		    PORTC_set_pin_dir(pin,mode);
		    break;
		case PORT_D:
		    PORTD_set_pin_dir(pin,mode);
		    break;
		case PORT_E:
		    PORTE_set_pin_dir(pin,mode);
		    break;
		case PORT_F:
		    PORTF_set_pin_dir(pin,mode);
		    break;
		default:
			break;
	}
}

/**
 * @brief Set pin's pull resistor
 * @param port Pin's port
 * @param pin Pin
 * @param pull Pull resistor
 */
void GpioWrapper_setPull(Gpio_portId_t port, Gpio_pinId_t pin, Gpio_pull_t pull)
{
    switch(port)
	{
        case PORT_A:
		    PORTA_set_pin_pull_mode(pin,pull);
		    break;
		case PORT_B:
		    PORTB_set_pin_pull_mode(pin,pull);
		    break;
		case PORT_C:
		    PORTC_set_pin_pull_mode(pin,pull);
		    break;
		case PORT_D:
		    PORTD_set_pin_pull_mode(pin,pull);
		    break;
		case PORT_E:
		    PORTE_set_pin_pull_mode(pin,pull);
		    break;
		case PORT_F:
		    PORTF_set_pin_pull_mode(pin,pull);
		    break;
		default:
		    break;
	}
}

/**
 * @brief Set pin's speed
 * @param port Pin's port
 * @param pin Pin
 * @param speed Speed
 */
void GpioWrapper_setSpeed(Gpio_portId_t port, Gpio_pinId_t pin, Gpio_speed_t speed)
{
    // No Speed settings
}

/**
 * @brief Write value to port
 * @param port Port to be written
 * @param value Value to be written to port
 */
void GpioWrapper_WritePort(Gpio_portId_t port, Gpio_data_t value)
{
    switch(port)
    {
	    case PORT_A:
	        PORTA_write_port(value);
	        break;
	    case PORT_B:
	        PORTB_write_port(value);
	        break;
	    case PORT_C:
	        PORTC_write_port(value);
	        break;
	    case PORT_D:
	        PORTD_write_port(value);
	        break;
	    case PORT_E:
	        PORTE_write_port(value);
	        break;
	    case PORT_F:
	        PORTF_write_port(value);
	        break;
	    default:
	        break;
    }
}

/**
 * @brief Write value to GPIO pin
 * @param port Pin's port
 * @param pin Pin to be written
 * @param state Value to be written to pin
 */
void GpioWrapper_SetPin(Gpio_portId_t port, Gpio_pinId_t pin, Gpio_pinState_t state)
{
    switch(port)
    {
	    case PORT_A:
	        PORTA_set_pin_level(pin,state);
	        break;
	    case PORT_B:
	        PORTB_set_pin_level(pin,state);
	        break;
	    case PORT_C:
	        PORTC_set_pin_level(pin,state);
	        break;
	    case PORT_D:
	        PORTD_set_pin_level(pin,state);
	        break;
	    case PORT_E:
	        PORTE_set_pin_level(pin,state);
	        break;
	    case PORT_F:
	        PORTF_set_pin_level(pin,state);
	        break;
	    default:
	        break;
    }   
}

/**
 * @brief Read port's value
 * @param port Pin's port
 * @return Port's value
 */
Gpio_data_t GpioWrapper_ReadPort(Gpio_portId_t port)
{
	Gpio_data_t portValue;
    switch(port)
    {
	    case PORT_A:
	        portValue = PORTA_get_port_level();
	        break;
	    case PORT_B:
	        portValue = PORTB_get_port_level();
	        break;
	    case PORT_C:
	        portValue = PORTC_get_port_level();
	        break;
	    case PORT_D:
	        portValue = PORTD_get_port_level();
	        break;
	    case PORT_E:
	        portValue = PORTE_get_port_level();
	        break;
	    case PORT_F:
	        portValue = PORTF_get_port_level();
	        break;
	    default:
		    portValue = LOW;
	        break;
    }
    return portValue;
}

/**
 * @brief Read GPIO pin's value
 * @param port Pin's port
 * @param pin Pin to be read
 * @return Pin's value
 */
Gpio_pinState_t GpioWrapper_GetPin(Gpio_portId_t port, Gpio_pinId_t pin)
{
    volatile Gpio_pinState_t pinState;
    switch(port)
    {
	    case PORT_A:
	        pinState = PORTA_get_pin_level(pin);
	        break;
	    case PORT_B:
	        pinState = PORTB_get_pin_level(pin);
	        break;
	    case PORT_C:
	        pinState = PORTC_get_pin_level(pin);
	        break;
	    case PORT_D:
	        pinState = PORTD_get_pin_level(pin);
	        break;
	    case PORT_E:
	        pinState = PORTE_get_pin_level(pin);
	        break;
	    case PORT_F:
	        pinState = PORTF_get_pin_level(pin);
	        break;
	    default:
		    pinState = LOW;
	        break;
    }
    return pinState;
}
